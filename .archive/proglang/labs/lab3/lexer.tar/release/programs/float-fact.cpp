int main ( ) {
    float n, i, f;
    n = 3.0;
    i = 1.0;
    f = 1.0;
    while (i < n) {
        i = i + 1.0;
        f = f * i;
    }
}
