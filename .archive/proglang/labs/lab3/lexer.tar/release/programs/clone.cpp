int main ( ) {
    int a, b, c, d;
    b = a;
    b = 5;
    d = c;
    c = 7;
}
