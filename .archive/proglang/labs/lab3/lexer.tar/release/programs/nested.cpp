int main ( ) {
    float a, b, c, d;
    a = 5.0; b = 4.5;
    c = 3.3; d = 2.2;
    a = (b * float(1)) + (c - d);
}
