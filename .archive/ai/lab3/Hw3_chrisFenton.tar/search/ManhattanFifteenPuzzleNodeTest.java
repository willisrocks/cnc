package search;

import static org.junit.Assert.*;
import org.junit.Test;

public class ManhattanFifteenPuzzleNodeTest {

	@Test
	public void testEvaluate() {
		assertEquals(5, new ManhattanFifteenPuzzleNode("ABCDEFGHIJO.MNLK").getHeuristicEvaluation(), 0.01);
	}

}
